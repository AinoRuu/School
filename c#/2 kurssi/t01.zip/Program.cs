﻿namespace t01;

class Program
{



    static void Main(string[] args)
    {
        KokonaisLuku koko = new KokonaisLuku();

        Console.WriteLine("Anna kokonaisluku");
        int vastaus = int.Parse(Console.ReadLine());
        koko.First = vastaus;

        Console.WriteLine("Anna kokonaisluku");
        vastaus = int.Parse(Console.ReadLine());
        koko.Second = vastaus;

        Console.WriteLine();
        
        koko.Print();
    }
}
