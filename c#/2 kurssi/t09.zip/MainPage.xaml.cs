﻿namespace t09;

public partial class MainPage : ContentPage
{


	public MainPage()
	{
		InitializeComponent();
	}

	private void OnBtnClicked(object sender, EventArgs e)
	{
		var color = new Random();

		if (BackgroundColor != Colors.Red)
		{
			BackgroundColor = Colors.Red;
		}
		else if (BackgroundColor == Colors.Red) 
		{
            int alpha = color.Next(0, 255);
			int red = color.Next(0, 255);
			int blue = color.Next(0, 255);
			int green = color.Next(0, 255);

			BackgroundColor =Color.FromRgb(red, green, blue);
        }
		
		
		
	
	}



}

