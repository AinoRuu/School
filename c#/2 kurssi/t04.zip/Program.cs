﻿using System.Reflection.Metadata.Ecma335;
using System.Transactions;

namespace t04;

class Program
{
    public struct Person 
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
    }

    static void Print(Person Person)
    {
        DateTime now = DateTime.Now;

        int year = now.Year;

        int Age =  year - Person.DateOfBirth.Year;


        Console.WriteLine(Person.FirstName + " " + Person.LastName + ", " + Age + " years");
    }

    public struct Employee
    {
        public string JobTitle { get; set; }

        public DateTime JobStart { get; set; }

        public DateTime JobEnd { get; set; }

        public Person Person { get; set; }
    }
    static int EmploymentLength(Employee employee1)
    {
        DateTime now = DateTime.Now;

        int year = now.Year;

        int Lenght = employee1.JobEnd.Year - employee1.JobStart.Year;

        return Lenght;

    }

    static void Main(string[] args)
    {
        Person person1 = new Person();
        Employee employee1 = new Employee();
        Console.WriteLine("Insert personal info on employee 1");
        Console.WriteLine();


        Console.Write("Firstname: ");
        person1.FirstName = Console.ReadLine();

        Console.Write("Lastname: ");
        person1.LastName = Console.ReadLine();

        Console.Write("Date of birth: (dd.mm.yyyy)");
        person1.DateOfBirth = DateTime.Parse(Console.ReadLine());

        Console.WriteLine();
        Console.WriteLine("Insert employment info on employee 1");
        Console.WriteLine();

        Console.Write("Jobtitle: ");
        employee1.JobTitle = Console.ReadLine();

        Console.Write("Date of the beginning of the employment: (dd.mm.yyyy)");
        employee1.JobStart = DateTime.Parse(Console.ReadLine());

        Console.Write("Date of the end of the employment: (dd.mm.yyyy)");
        employee1.JobEnd = DateTime.Parse(Console.ReadLine());

        employee1.Person = person1;

        Print(person1);

        int Length1 = EmploymentLength(employee1);

        Console.WriteLine("{0} {1} has been working for {2} years.",person1.FirstName, person1.LastName, Length1);

    }
}
