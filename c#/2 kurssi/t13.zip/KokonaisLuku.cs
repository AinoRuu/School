﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t13
{
    internal class KokonaisLuku
    {
        public int First { get; set; }
        public int Second { get; set; }

        public void Print()
        {
            Console.WriteLine("Syöttämiesi kokonaislukujen summa on {0}", Second + First);
        }
    }
}
