﻿namespace t03;

class Program
{
    public struct ToinenAste
    {
        public int a { get; set; }
        public int b { get; set; }
        public int c { get; set; }


        
    }
    public struct Ratkaisu
    {
        public double x1 { get; set; }
        public double x2 { get; set; }
    }

    static Ratkaisu Ratkaise(ToinenAste ToinenAste)
    {

        Ratkaisu Ratkaisu = new Ratkaisu(); 
        double sqrtpart = (ToinenAste.b * ToinenAste.b) - (4 * ToinenAste.a * ToinenAste.c);
        double answer1 = (-(ToinenAste.b) + Math.Sqrt(sqrtpart));
        double answer2 = (-(ToinenAste.b) - Math.Sqrt(sqrtpart));
        Ratkaisu.x1 = answer1 / (2 * ToinenAste.a);
        Ratkaisu.x2 = answer2 / (2 * ToinenAste.a);

        return Ratkaisu;


    }
    

    static void Main(string[] args)
    {
        ToinenAste ToinenAste = new ToinenAste();
        Ratkaisu Ratkaisu = new Ratkaisu();
        Console.WriteLine("Anna a:");
        ToinenAste.a = int.Parse(Console.ReadLine());

        Console.WriteLine("Anna b:");
        ToinenAste.b = int.Parse(Console.ReadLine());

        Console.WriteLine("Anna c:");
        ToinenAste.c = int.Parse(Console.ReadLine());


        Ratkaisu = Ratkaise(ToinenAste);
       

        Console.WriteLine("Yhtälösi ratkaisut ovat x = {0} ja/tai x = {1}.",Ratkaisu.x1, Ratkaisu.x2);
        Console.WriteLine("Mikäli sait vastaukseksi 'epäluku' vaatii lasku, yhtälöllä ei välttämättä ole ratkaisuja. Laske diskriminantti.");
    }
}
