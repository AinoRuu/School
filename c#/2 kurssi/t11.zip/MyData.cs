﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t11
{
    public struct Henkilo
    {
        public string Nimi { get; set; }
        public string Osoite { get; set; }
        public string Puhelin { get; set; }
        public string Sahkoposti { get; set; }
    }
}
