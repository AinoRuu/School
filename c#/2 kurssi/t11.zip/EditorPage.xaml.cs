using System.ComponentModel;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace t11;

public partial class EditorPage : ContentPage
{

    private readonly MainPage _mainPage;
	public EditorPage(MainPage mainPage)
	{
		InitializeComponent();

        _mainPage = mainPage;
	}


    public void DataFromEditorPage(Henkilo henkilo)
    {
        Name.Text = henkilo.Nimi;
        Address.Text = henkilo.Osoite;
        Phone.Text = henkilo.Puhelin;
        Email.Text = henkilo.Sahkoposti;

    }

    private void Bring_Clicked(object sender, EventArgs e)
    {
        Henkilo henkilo = _mainPage.DataFromMainPage();
        DataFromEditorPage(henkilo);
    }


    private async void Take_Clicked(object sender, EventArgs e)
    {
        Henkilo henkilo = new Henkilo
        {
            Nimi = Name.Text,
            Osoite = Address.Text,
            Puhelin = Phone.Text,
            Sahkoposti = Email.Text
        };

        _mainPage.BringDataToMainPage(henkilo);

        await Navigation.PopAsync();  

    }
}