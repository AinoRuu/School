﻿using System.Net;
using System.Xml.Linq;
using Windows.Storage;
using Windows.UI.Notifications;
using static Microsoft.Maui.ApplicationModel.Permissions;

namespace t11;

public partial class MainPage : ContentPage
{

    public MainPage()
    {
        InitializeComponent();
    }

    private Henkilo henkilo;

    public Henkilo DataFromMainPage()
    {
        henkilo.Nimi = EtuSuku.Text;
        henkilo.Osoite = Os.Text;
        henkilo.Sahkoposti = SaPo.Text;
        henkilo.Puhelin = PuhNro.Text;

        return henkilo;

    }
    public void BringDataToMainPage(Henkilo data)
    {
        EtuSuku.Text = data.Nimi;
        Os.Text = data.Osoite.ToString();
        PuhNro.Text = data.Puhelin.ToString();
        SaPo.Text = data.Sahkoposti.ToString();

    }

    private async void Open_Clicked(object sender, EventArgs e)
    {
        EditorPage editorPage = new(this);
        Henkilo henkilo = new Henkilo
        {
            Nimi = EtuSuku.Text,
            Osoite = Os.Text,
            Puhelin = PuhNro.Text,
            Sahkoposti = SaPo.Text
        };

        editorPage.DataFromEditorPage(henkilo);

        await Navigation.PushAsync(editorPage);


    }

    private void Quit_Clicked(object sender, EventArgs e)
    {
        Application.Current.Quit();
    }

    
}




