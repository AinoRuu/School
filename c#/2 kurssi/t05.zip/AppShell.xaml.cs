﻿namespace t05;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
