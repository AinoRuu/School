﻿namespace t05;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}
}

