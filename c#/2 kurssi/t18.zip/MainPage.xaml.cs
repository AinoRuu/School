﻿using CommunityToolkit.Maui;
using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Storage;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using Windows.Storage.Pickers;

namespace t18;

public partial class MainPage : ContentPage
{
    string file;


	public MainPage()
	{
		InitializeComponent();
        file = Directory.GetCurrentDirectory();

	}

    private void Uusi_Clicked(object sender, EventArgs e)
    {
        TextField.Text = "";
        Osoite.Text = "";
    }
    async Task SaveFile(CancellationToken cancellationToken)
    {
        using var stream = new MemoryStream(Encoding.Default.GetBytes(TextField.Text));
        var fileSaverResult = await FileSaver.Default.SaveAsync("text.txt", stream, cancellationToken);
        if (fileSaverResult.IsSuccessful)
        {
            await Toast.Make($"Tiedosto tallennettiin onnistuneesti kohteeseen: {fileSaverResult.FilePath}").Show(cancellationToken);
        }
        else
        {
            await Toast.Make($"Tiedostoa ei voitu tallentaa seuraavan virheen vuoksi: {fileSaverResult.Exception.Message}").Show(cancellationToken);
        }
    }

    public async Task<FileResult> PickAndShow(PickOptions options)
    {
        try
        {
            var result = await FilePicker.Default.PickAsync(options);
            if (result != null)
            {
                if (result.FileName.EndsWith(".txt", StringComparison.Ordinal))
                {
                    using var stream = await result.OpenReadAsync();
                    using StreamReader reader = new StreamReader(stream);
                    var text = reader.ReadToEnd();
                    TextField.Text = text;
                }
            }

            return result;
        }
        catch (Exception ex)
        {
            // The user canceled or something went wrong
        }

        return null;
    }
    private async void Avaa_Clicked(object sender, EventArgs e)
    {
        PickOptions options = new PickOptions();
        file = Directory.GetCurrentDirectory();
        TextField.Text = "";

        await PickAndShow(options);

    }

    private async void Tallenna_Clicked(object sender, EventArgs e)
    {
        file = Directory.GetCurrentDirectory();
        if (TextField.Text != "")
        {
            if (File.Exists(file))
            {
                using (StreamWriter sw = File.CreateText(file))
                {
                    sw.Write(TextField.Text);

                }


            }
            else
            {
                await SaveFile(CancellationToken.None);

            }
        }
        
        Osoite.Text = file;



    }

    private async void Tallenna_nimella_Clicked(object sender, EventArgs e)
    {
        await SaveFile(CancellationToken.None);
    }

    private void Lopeta_Clicked(object sender, EventArgs e)
    {
        App.Current.Quit();
    }
}

