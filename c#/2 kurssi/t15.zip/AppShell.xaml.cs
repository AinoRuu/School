﻿namespace t15;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
