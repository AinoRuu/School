﻿namespace t15;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}

 

    private void Unfocused(object sender, FocusEventArgs e)
    {
        if (Toka.Text != null)
        {
            

            try
            {
                int.Parse(Toka.Text);
                Toka.BackgroundColor = Colors.White;
                ToolTipProperties.SetText(Toka, null);
            }
            catch (FormatException)
            {
                Toka.BackgroundColor = Colors.Red;
                Toka.Focus();
                ToolTipProperties.SetText(Toka, "Virheellinen syöte");
            }

        }

        if (Eka.Text != null)
        {
            
            try
            {
                int.Parse(Eka.Text);
                Eka.BackgroundColor = Colors.White;
                ToolTipProperties.SetText(Eka, null);
                
            }
            catch (FormatException)
            {
                Eka.BackgroundColor = Colors.Red;
                Eka.Focus();
                ToolTipProperties.SetText(Eka, "Virheellinen syöte");
                
            }
            
        }
        
    }
}

