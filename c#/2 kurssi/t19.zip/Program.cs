﻿using Microsoft.VisualBasic.FileIO;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;

namespace t19;

class Program
{
    static void Main(string[] args)
    {
        string Directory = FileSystem.CurrentDirectory;
        string filename = "Pelaajatiedot.json";
        string fullpath = Path.Combine(Directory, filename);

        List<Pelaaja> pelaajaLista = new List<Pelaaja>();


        string Name  = "alku";
        do
        {
            Pelaaja pelaaja1 = new Pelaaja();
            Console.WriteLine("Syötä pelaajan nimi:");
            Name = Console.ReadLine();
            pelaaja1.Nimi = Name;
            Console.WriteLine("Syötä pelaajan pisteet:");
            pelaaja1.Pisteet = Console.ReadLine();

            pelaajaLista.Add(pelaaja1);

        } while (Name != "");

        pelaajaLista.RemoveAll(x => x.Nimi == "");

        Console.WriteLine(fullpath);
        string jsonString = JsonSerializer.Serialize(pelaajaLista);
        File.WriteAllText(fullpath, jsonString);

        Console.WriteLine(jsonString);

    }
}
