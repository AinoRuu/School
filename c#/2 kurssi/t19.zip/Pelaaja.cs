﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t19
{
    public class Pelaaja
    {
        public string Nimi { get; set; }
        public string Pisteet { get; set; }
        
    }
}
