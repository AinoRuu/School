﻿namespace t06;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
