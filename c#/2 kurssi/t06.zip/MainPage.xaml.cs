﻿namespace t06;

public partial class MainPage : ContentPage
{

	public const string DEFAULT_VALUE = "1";

	public MainPage()
	{
		InitializeComponent();
	}

    private void Tuplausnappi_Clicked(object sender, EventArgs e)
    {
		string value = Lukuarvo.Text;

		if (int.TryParse(value, out int number))
		{
			number = number * 2;
			Lukuarvo.Text = number.ToString();
		}
		else
		{
            Lukuarvo.Text = DEFAULT_VALUE;
        }
    }
}

