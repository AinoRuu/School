﻿namespace t10;

public partial class MainPage : ContentPage
{


	public MainPage()
	{
		InitializeComponent();
	}

	private void OnBtnClicked(object sender, EventArgs e)
	{
        double length = double.Parse(Length.Text);
        double weight = double.Parse(Weight.Text);
        double length2 = (length * length);
        double BMI = weight / length2;
        Color merkkaus = Colors.LightGray;
        BMI = Math.Round(BMI, 1);

        aliravitsemus.BackgroundColor = Colors.Transparent;
        liikalaiha.BackgroundColor = Colors.Transparent;
        normaali.BackgroundColor = Colors.Transparent;
        ylipaino.BackgroundColor = Colors.Transparent;
        merkittava.BackgroundColor = Colors.Transparent;
        vaikea.BackgroundColor = Colors.Transparent;
        sairalloinen.BackgroundColor = Colors.Transparent;


        if (BMI < 17)
		{
            aliravitsemus.BackgroundColor = merkkaus;
		}
		else if (BMI >= 17 && BMI < 18.5) 
		{ 
            liikalaiha.BackgroundColor = merkkaus;
		}
        else if (BMI >= 18.5 && BMI < 25)
        {
            normaali.BackgroundColor = merkkaus;
            
        }
        else if (BMI >= 25 && BMI < 30)
        {
            ylipaino.BackgroundColor = merkkaus;
        }
        else if (BMI >= 30 && BMI < 35)
        {
            merkittava.BackgroundColor = merkkaus;
        }
        else if (BMI >= 35 && BMI <= 40)
        {
            vaikea.BackgroundColor = merkkaus;
        }
        else if (BMI > 40)
        {
            sairalloinen.BackgroundColor = merkkaus;
        }

    }


}

