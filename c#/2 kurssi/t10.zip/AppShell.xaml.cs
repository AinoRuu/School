﻿namespace t10;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
