﻿using System.ComponentModel.Design;

namespace t16;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}

    private async void Check_Clicked(object sender, EventArgs e)
    {
		string day = Day.Text;
		string month = Month.Text;
		string year = Year.Text;

        try
        {
            CheckDate(day, month, year);
            await DisplayAlert("Tarkistus valmis", "Päivämäärä oli oikein", "OK");
        }
        catch(Exception ex)
        {
            await DisplayAlert("Virhe", ex.Message, "OK");
        }


       

    }
	private bool CheckDate(string day, string month, string year)
	{
        int numbDay, numbMonth, numbYear;
        try
            {
                numbDay = int.Parse(day);
            }
            catch (Exception)
            {
            throw new Exception(message: "Päivä ei ollut numero");
            }

        try
        {
            numbMonth = int.Parse(month);
        }
        catch (Exception)
        {
            throw new Exception(message: "Kuukausi ei ollut numero");
        }

        try
        {
            numbYear = int.Parse(year);
        }
        catch (Exception)
        {
            throw new Exception(message: "Vuosi ei ollut numero");
        }

        if (numbDay < 1 || numbDay > 31)
        {
            throw new Exception("Päivä ei ollut annetulla välillä");
        }

        if (numbMonth < 1 || numbMonth > 12)
        {
            throw new Exception("Kuukausi ei ollut annetulla välillä");
        }
        
        if (numbYear < 1 || numbYear > 3000)
        {
            throw new Exception("Vuosi ei ollut annetulla välillä");
        }
        
        return true;

	}
}

