﻿using System.Runtime.CompilerServices;
using System.Text.Json;

namespace t17;



public partial class MainPage : ContentPage
{
    string cacheDir = FileSystem.Current.CacheDirectory;
    string filename = "teksti.json";
    string fullPath;





    public MainPage()
	{
		InitializeComponent();
        fullPath = Path.Combine(cacheDir, filename);
        

    }


    private void Read_Clicked(object sender, EventArgs e)
    {
          if(File.Exists(fullPath))
          {
                string json = File.ReadAllText(fullPath);
                string teksti =JsonSerializer.Deserialize<string>(json);
                TextField.Text = teksti;
          }
    }

    private void Save_Clicked(object sender, EventArgs e)
    {

        string teksti = TextField.Text;
        string json = JsonSerializer.Serialize(teksti);
        File.WriteAllText(fullPath, json);

        TextField.Text = "";
    }

    private void Quit_Clicked(object sender, EventArgs e)
    {
        App.Current.Quit();
    }
}

