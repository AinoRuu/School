﻿namespace t08;

public partial class MainPage : ContentPage
{


	public MainPage()
	{
		InitializeComponent();
	}

	public async void OnButtonClicked(object sender, EventArgs e)
	{
        var result = await FilePicker.PickAsync(new PickOptions
        {
            FileTypes = FilePickerFileType.Images
        });
        if (result.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) ||
            result.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
        {
            var stream = await result.OpenReadAsync();
            ImagePicked.Source = ImageSource.FromStream(() => stream);
        }
    }
}

