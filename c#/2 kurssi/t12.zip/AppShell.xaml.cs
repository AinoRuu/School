﻿namespace t12;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
