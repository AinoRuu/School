﻿using System.Collections.ObjectModel;

namespace t12;

public partial class MainPage : ContentPage
{

	// Lisätietoja ObservableCollection, https://learn.microsoft.com/en-us/dotnet/api/system.collections.objectmodel.observablecollection-1?view=net-7.0
	// Tähän kokoelmaan voi lisätä henkilöitä ja tämä kokoelma sidotaan ListView-komponenttiin
    public ObservableCollection<PersonInfo> People { get; set; }
    public MainPage()
	{
        InitializeComponent();
        // jätä alla olevat alustukset paikoilleen
        People = new ObservableCollection<PersonInfo>();
        BindingContext = this;
	}

    private void Add_Clicked(object sender, EventArgs e)
    {
        PersonInfo person = new PersonInfo();
        person.Name = Nimi.Text;
        person.Address = Os.Text;
        person.Phone = PuhNro.Text;
        person.Email = SaPo.Text;
        People.Add(person);
    }


    private void PeopleInfo_ItemSelected(object sender, SelectedItemChangedEventArgs e)
    {
        PersonInfo personInfo = e.SelectedItem as PersonInfo;

        Nimi.Text = personInfo.Name;
        Os.Text = personInfo.Address;
        PuhNro.Text = personInfo.Phone;
        SaPo.Text = personInfo.Email;

        People.Remove(personInfo);

    }
}

