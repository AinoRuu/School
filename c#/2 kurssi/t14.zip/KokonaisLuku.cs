﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t14
{
    internal class KokonaisLuku
    {
        public int First { get; set; }
        public int Second { get; set; }

        public void Print()
        {
            double exponent = Math.Pow(First, Second);
            double divide = First / Second;
            Console.WriteLine("{0} in the power of {1} equals {2}", First, Second, exponent);
            Console.WriteLine("{0} divided by {1} equals {2}", First, Second, divide);
        }
    }
}
