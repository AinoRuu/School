﻿namespace t14;

class Program
{
    static void Main(string[] args)
    {
        KokonaisLuku koko = new KokonaisLuku();

        try
        {
            Console.WriteLine("Enter an integer");
            int vastaus = int.Parse(Console.ReadLine());
            koko.First = vastaus;

            Console.WriteLine("Enter an integer");
            vastaus = int.Parse(Console.ReadLine());
            koko.Second = vastaus;

            Console.WriteLine();

            koko.Print();
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Exception! Tried to divide by zero.");
        }
        catch (FormatException)
        {
            Console.WriteLine(); 
            Console.WriteLine("Exception! Input was in the wrong format.");
        }
    }
}
