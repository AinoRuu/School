﻿namespace t02;

class Program
{

    static void LaskeKeskiIka(string[] taulukko)
    {
        int ika = 0;
        for (int i = 1; i < taulukko.Length; i+=2)
        {
            ika = ika + int.Parse(taulukko[i]);
        }
        int KeskiIka = ika / 5;
        Console.WriteLine("Henkilöiden {0}, {1}, {2}, {3} ja {4} keski-ikä on {5}",taulukko[0], taulukko[2], taulukko[4], taulukko[6], taulukko[8], KeskiIka);
    }

    static void Main(string[] args)
    {
        string[] taulukko = new string[10];

        Henkilo henkilo1 = new Henkilo();

        henkilo1.FirstName = "Martti";
        henkilo1.LastName = "Matilainen";
        henkilo1.Age = "23";


        taulukko[0] = henkilo1.FirstName + " " + henkilo1.LastName;
        taulukko[1] = henkilo1.Age;

        Henkilo henkilo2 = new Henkilo();

        henkilo2.FirstName = "Maija";
        henkilo2.LastName = "Matilainen";
        henkilo2.Age = "25";

        taulukko[2] = henkilo2.FirstName + " " + henkilo2.LastName;
        taulukko[3] = henkilo2.Age;

        Henkilo henkilo3 = new Henkilo();

        henkilo3.FirstName = "Marja-Leena";
        henkilo3.LastName = "Matilainen";
        henkilo3.Age = "70";

        taulukko[4] = henkilo3.FirstName + " " + henkilo3.LastName;
        taulukko[5] = henkilo3.Age;

        Henkilo henkilo4 = new Henkilo();

        henkilo4.FirstName = "Markku";
        henkilo4.LastName = "Matilainen";
        henkilo4.Age = "75";

        taulukko[6] = henkilo4.FirstName + " " + henkilo4.LastName;
        taulukko[7] = henkilo4.Age;

        Henkilo henkilo5 = new Henkilo();

        henkilo5.FirstName = "Miisa";
        henkilo5.LastName = "Matilainen";
        henkilo5.Age = "5";

        taulukko[8] = henkilo5.FirstName + " " + henkilo5.LastName;
        taulukko[9] = henkilo5.Age;
        
        LaskeKeskiIka(taulukko);
    }
}
