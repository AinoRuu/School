using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
Lue käyttäjältä kaksi kokonaislukua sekä operaatio joka lukujen välillä
suoritetaan (voi olla +, -, * tai / eli kyseessä siis nelilaskin).

Käytä operaation tallentamiseen string-tyyppistä muuttujaa.

Tutki switch-case rakenteessa minkä operaation käyttäjä syötti ja
tulosta sen perusteella lukujen laskutoimitus vastauksineen. Osamäärä
tulostetaan kahden desimaalin tarkkuudella

Esimerkiksi
jos käyttäjä syöttää luvut "12" ja "13" ja operaatioksi "+" niin tulostetaan

12 + 13 = 25

Jos operaatio oli annettu väärin, niin tulosta virheilmoitus
"annoit operaation väärin"

Nollalla jakoa ei saa ohjelmassa tapahtua, vaan silloin tulostetaan
"Nollalla jako, ei voida suorittaa"
*/

namespace Projekti
{
    class Program
    {
        static void Main()
        {
            //Your code here
            //
            Console.WriteLine("Anna ensimmäinen kokonaisluku");
            float fFirst = float.Parse(Console.ReadLine());
            Console.WriteLine("Anna toinen kokonaisluku");
            float fSecond = float.Parse(Console.ReadLine());
            Console.WriteLine("Anna operaatio (+, -, * tai /)");
            string sOperaatio = Console.ReadLine();
            float fTulo = fFirst * fSecond;
            float fSumma = fFirst + fSecond;
            float fErotus = fFirst - fSecond;
            float fJako = 0.0f;

            switch (sOperaatio) 
            {
                case "*":
                    Console.WriteLine("{0} * {1} = {2}",fFirst, fSecond, fTulo);
                    break;
                case "/":
                    if (fFirst == 0)
                    {
                        Console.WriteLine("Nollalla jako, ei voida suorittaa");
                    }
                    else if (fSecond == 0)
                    {
                        Console.WriteLine("Nollalla jako, ei voida suorittaa");
                    }
                    else if (fFirst == 0 && fSecond == 0)
                    {
                        Console.WriteLine("Nollalla jako, ei voida suorittaa");
                    }
                    else
                    {
                        fJako = fFirst / fSecond;
                        
                        Console.WriteLine("{0} / {1} = {2:F2}", fFirst, fSecond, fJako);
                    }  
                    break;
                case "+":
                    Console.WriteLine("{0} + {1} = {2}", fFirst, fSecond, fSumma);    
                    break;
                case "-": 
                    Console.WriteLine("{0} - {1} = {2}", fFirst, fSecond, fErotus);
                    break;
                default: 
                    Console.WriteLine("annoit operaation väärin");
                    break;
            }
        }
    }
}

