using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

/*
Lue käyttäjältä ympyrän säde liukulukuna.

Kysy käyttäjältä myös, haluaako hän tehdä kumpaa seuraavista
(eli käyttäjä syöttää joko numeron 1 tai 2) :

    1 = laske ympyrän piiri
    2 = laske ympyrän pinta-ala

Tämän vastauksen perusteella laske dTulos-muuttujaan joko piiri
tai pinta-ala ja tulosta se. 

Toteuta sovellus:
1. if-rakenteella
2. ehdollisella operaattorilla.

Tulostus pitää siis tehdä kaksi kertaa, eli molemmat rakenteet toteuttavat saman logiikan, alla olevalla tavalla:

Tulos : 12.22
Tulos : 12.22
*/

namespace Projekti
{
    class Program
    {
        static void Main()
        {
            //Your code here
            Console.WriteLine("Syötä ympyrän säde:");
            float fSade = float.Parse(Console.ReadLine());
            Console.WriteLine("Lasketaanko piiri (syötä 1) vai pinta-ala (syötä 2)?");
            int iChoice = int.Parse(Console.ReadLine());

            //muuttujille arvot
            float fPii = 3.141592f;
            float fPiiri = 2 * fPii * fSade;
            float fAla = fPii * (fSade * fSade);

            //ensin if-lausekkeen avulla
            if (iChoice == 1)
            {
                Console.WriteLine("Tulos : {0:F2}",fPiiri);
            }
            else if (iChoice == 2)
            {
                Console.WriteLine("Tulos : {0:F2}", fAla);
            }

            //sitten ehdollisella operaattorilla

            string tulostus = "";
            tulostus = iChoice == 1 ? ("Tulos : "+ String.Format("{0:0.00}",fPiiri)) : ("Tulos : " + String.Format("{0:0.00}", fAla));
            Console.WriteLine(tulostus);
            
        }
    }
}

